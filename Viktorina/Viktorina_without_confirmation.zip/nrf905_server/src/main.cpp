#include <Arduino.h>
#include <SPI.h>
#include <RH_NRF905.h>
#include <DFPlayerMini_Fast.h>
#include <SoftwareSerial.h>

#define CARIER_DETECT_PIN 2
#define CHA_PIN 4
#define CHB_PIN 5
#define CHC_PIN 6
#define CHD_PIN 7
#define COUNT_OF_BUTTONS 5

SoftwareSerial mySerial(A1, A0); // RX, TX
RH_NRF905 nrf905;
DFPlayerMini_Fast myMP3;

uint8_t part;
bool last;

void SendDataToActive();
void SendResetData();

struct dataStruct
{
    uint8_t id;
    uint8_t ledColor;
    bool enable;
} incomData;

void setup()
{
    Serial.begin(57600);
    mySerial.begin(9600);

    pinMode(CARIER_DETECT_PIN, INPUT);
    pinMode(CHC_PIN, INPUT);
    pinMode(CHD_PIN, INPUT);
    pinMode(CHA_PIN, INPUT);
    pinMode(CHB_PIN, INPUT);

    if (!nrf905.init())
        Serial.println("nrf905 init failed");
    else
        Serial.println("nrf905 init OK");

    // Defaults after init are 433.2 MHz (channel 108), -10dBm
    nrf905.setRF(RH_NRF905::TransmitPower10dBm);
    delay(10);
    nrf905.setChannel(100); // 434.0 MHz (116)
    delay(10);

    myMP3.begin(mySerial);
    delay(100);
    myMP3.volume(30);
    delay(100);
}

void loop()
{
    switch (part)
    {
    case 0:
        if (nrf905.available())
        {
            delay(10);

            uint8_t buf[RH_NRF905_MAX_MESSAGE_LEN];
            uint8_t buflen = sizeof(buf);

            last = false;

            if (nrf905.recv((uint8_t *)(&incomData), &buflen))
            {
                Serial.println("\nGot button:");
                Serial.println("ID: " + String(incomData.id));
                Serial.println("Color: " + String(incomData.ledColor));
                Serial.println("Enable: " + String(incomData.enable));

                myMP3.play(3);

                incomData.ledColor = 0; // set red light
                SendDataToActive();     // return red light

                part++;
            }
        }

        break;
    case 1:
        if (digitalRead(CHA_PIN)) // right variant
        {
            Serial.println("\nRight answer, reset system");

            myMP3.play(2);

            SendResetData();

            part = 0;
        }
        else if (digitalRead(CHB_PIN)) // wrong variant
        {
            Serial.println("\nWrong answer, block button");

            myMP3.play(1);

            incomData.ledColor = 2;
            incomData.enable = false;

            SendDataToActive();

            part = 0;
        }

        break;
    }

    if (!last && digitalRead(CHC_PIN))
    {
        last = true;
        SendResetData();
        part = 0;
    }
}

void SendDataToActive()
{
    while (digitalRead(CARIER_DETECT_PIN))
        ;
    delay(10);

    Serial.println("\nSend data to button:");
    Serial.println("ID: " + String(incomData.id));
    Serial.println("Color: " + String(incomData.ledColor));
    Serial.println("Enable: " + String(incomData.enable));

    nrf905.send((uint8_t *)&incomData, sizeof(incomData));

    if (nrf905.waitPacketSent())
        Serial.println("\nData sended");
}

void SendResetData()
{
    Serial.println();

    for (size_t i = 0; i < COUNT_OF_BUTTONS; i++)
    {
        incomData.id = i;
        incomData.ledColor = 1; // set green color
        incomData.enable = true;

        while (digitalRead(CARIER_DETECT_PIN))
            ;
        delay(50);

        nrf905.send((uint8_t *)&incomData, sizeof(incomData));

        if (nrf905.waitPacketSent())
            Serial.println("All buttons reseted");
    }
}